package examplegame;

public interface Attacker {
    int getEffectiveDamage();
}
